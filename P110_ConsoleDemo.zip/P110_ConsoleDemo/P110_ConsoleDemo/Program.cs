﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace P110_ConsoleDemo
{
    #region Subjects
    //enum - sadalamaq
    //struct
    //Generic type

    //interface
    //Collections & Collections.Generic namespace

    //delegate
    //event

    //Thread, Task
    //Reflection
    #endregion

    class Program
    {
        static void Main(string[] args)
        {
            #region Custom interface - ISortable
            //Student[] students = {
            //    new Student{ Name = "Ilkin", Age = 12 },
            //    new Student{ Name = "Tebriz", Age = 45 },
            //    new Student{ Name = "Aqil", Age = 39 },
            //    new Student{ Name = "Mixcan", Age = 25 },
            //    new Student{ Name = "Medis", Age = -5 }
            //};

            //Sort(students);

            //foreach (var item in students)
            //{
            //    Console.WriteLine(item);
            //}
            #endregion

            #region Collections
            //System.Collection
            //System.Collection.Generic
            //System.Collection.Concurrent

            //ArrayList arrayList = new ArrayList();
            //arrayList.Add("sdujfg");
            //arrayList.Add(25654);
            //arrayList.Add(new int[] { 15, 125 });

            //int[] n = { 10, 125, 12, 2 };

            //List<int> nums = new List<int>();
            //nums.Add(16);
            //nums.AddRange(n);

            //foreach (var item in nums)
            //{
            //    Console.WriteLine(item);
            //}

            //Queue<Person> people = new Queue<Person>();
            //people.Enqueue(new Person { Name = "Ilkin" });
            //people.Enqueue(new Person { Name = "Mixcan" });
            //people.Enqueue(new Person { Name = "Elmar" });

            //Console.WriteLine(people.Peek());
            //Console.WriteLine(people.Dequeue());

            //Stack<Person> people2 = new Stack<Person>();
            //people2.Push(new Person { Name = "Ramiz" });
            //people2.Push(new Person { Name = "Medis" });

            //Console.WriteLine(people2.Pop());

            Dictionary<string, string> phoneBook = new Dictionary<string, string>();
            phoneBook.Add("Ilkin", "+994 55 555 55 55");
            phoneBook.Add("Perviz", "+994 51 7893245");
            phoneBook.Add("Medine", "+994 050");

            Console.WriteLine(phoneBook["Perviz"]);


            #endregion

        }

        //static void Sort<T>(T[] array) 
        //{
        //    for (int i = 0; i < array.Length; i++)
        //    {
        //        int minIndex = i;
        //        for (int j = i + 1; j < array.Length; j++)
        //        {
        //            ISortable sortable = array[j] as ISortable;

        //            if (sortable == null)
        //                throw new InvalidCastException("At least one of the items should " +
        //                    "implement ISortable interface in order to be sortable.");

        //            if (sortable.Sort(array[minIndex]) < 0)
        //            {
        //                minIndex = j;
        //            }
        //        }

        //        Swap(array, minIndex, i);
        //    }
        //}

        //static void Swap<T>(T[] array, int i, int j)
        //{
        //    T temp = array[i];
        //    array[i] = array[j];
        //    array[j] = temp;
        //}
    }


    class Student : IComparable, ISortable
    {
        public int Age { get; set; }
        public string Name { get; set; }

        public int Sort(object obj)
        {
            Student student = (Student)obj;

            if (Age < student.Age) return -1;
            if (Age == student.Age) return 0;
            return 1;
        }

        public int CompareTo(object obj)
        {
            Student student = (Student)obj;

            //if (Age < student.Age) return -1;
            //if (Age == student.Age) return 0;
            //return 1;

            return Age.CompareTo(student.Age);

            //if (Name < student.Name) return -1;  
            //if (Name == student.Name) return 0;
            //return 1;

            //return Name.CompareTo(student.Name);
        }

        public override string ToString()
        {
            return $"{Name} {Age}";
        }
    }

    interface ISortable
    {
        /// <summary>
        /// This interface should be used for sorting in sort arrays
        /// </summary>
        /// <param name="obj"></param>
        /// <returns>if int is less than 0, first precedes second. if 0, they are equal. Else first followss second.</returns>
        int Sort(object obj);
    }
    
    #region Interface simple example
    class Person : IRunnable
    {
        public string Name { get; set; }

        public void Run()
        {
            throw new NotImplementedException();
        }

        public string TellName() => Name;

        public void Walk()
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            return Name;
        }
    }

    abstract class Animal
    {
        public string Sort { get; set; }
        public string GetSort() => Sort;
    }

    class Zebra : Animal, IRunnable
    {
        public void Run()
        {
        }

        public void Walk()
        {
            throw new NotImplementedException();
        }
    }

    class Snake : Animal { }

    class Monkey : Animal, IRunnable
    {
        public void Run()
        {
        }

        public void Walk()
        {
            throw new NotImplementedException();
        }
    }

    interface IRunnable : IWalkable
    {
        void Run();
    }

    interface IWalkable
    {
        void Walk();
    }
    #endregion

}

